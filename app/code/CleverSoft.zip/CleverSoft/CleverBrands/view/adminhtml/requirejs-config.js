var config = {
    map: {
        '*': {
            'xinchao':  'CleverSoft_CleverBrands/js/browser'
        }
    }
};